# 两项训练诊断：结果与解释

运行目录：`artifacts/diagnostics/20261111_110649_079619`。全部结果来自原验证划分；调制 20,885 条、协议 14,511 条，完整模型验证共 118,182 条。

## 诊断一：相同调制曝光下的多任务与单任务

两组均从相同随机权重开始，使用 17M 结构并开启 QK 归一化。每组 4,800 次调制更新，每批 256 条，累计 1,228,800 次调制样本曝光。
初始权重哈希、完整调制批次流哈希及日志内实际调制学习率均已核对相同。每 1,200 次调制更新为一个显示 epoch，共四段。
多任务组额外穿插协议和参数更新，因此共享 AdamW 状态及总更新次数不同。这是增加其他任务更新后的净效应对照，不是只隔离梯度冲突的实验。

| 训练方式 | 验证任务 | Accuracy | Macro-F1 | Weighted-F1 |
|---|---|---:|---:|---:|
| 多任务 | 调制 | 63.05% | 62.76% | 62.73% |
| 多任务 | 协议 | 94.46% | 94.44% | 94.47% |
| 仅调制 | 调制 | 60.72% | 60.12% | 60.09% |
| 仅调制 | 协议（未训练头，仅记录） | 28.16% | 17.94% | 17.75% |

多任务组调制准确率高 2.33 个百分点。这组早期训练对照不支持将多任务负迁移视为主要原因；它不能排除 96M 长期训练后期的干扰。

## 诊断二：冻结现有基座，重新训练分类头

现有小模型取第 5 轮检查点，大模型取第 44 轮检查点。编码器完全冻结，逐张量验证未改变。训练、验证特征均以 FP32 提取；两个新头使用同一份训练侧均值/标准差、相同批次顺序和优化配方。
Linear 与原形状 MLP 各训练固定 20 轮、两个种子（2026、2027）。以下报告最后一轮的种子均值，不按验证结果挑选轮次。原头使用原始特征，新头使用标准化特征，二者对比包含标准化及重新训练的组合影响。

| 基座 | 分类头 | 训练 Accuracy | 验证 Accuracy | Macro-F1 | Weighted-F1 |
|---|---|---:|---:|---:|---:|
| 17M | 原头 | 65.29% | 61.68% | 61.81% | 61.78% |
| 17M | 新 Linear | 67.44% | 63.21% | 62.95% | 62.93% |
| 17M | 新 MLP | 69.74% | 63.73% | 63.42% | 63.40% |
| 96M | 原头 | 99.94% | 64.24% | 64.17% | 64.16% |
| 96M | 新 Linear | 100.00% | 64.28% | 64.22% | 64.20% |
| 96M | 新 MLP | 100.00% | 64.29% | 64.25% | 64.24% |

小模型重新训练 MLP 有约 2 个百分点的收益，线性头没有优于 MLP，不能简单归因于 MLP 过于复杂。小模型原头的训练/验证差距也远小于大模型，不能将两个训练阶段统一解释为严重过拟合。
大模型两类新头的训练准确率接近 100%，验证仍约 64.28%。这支持将主要瓶颈定位到基座对新记录的泛化，而非这两类分类头的表达能力；不等同于证明任意读出方案都无效。
基座参考值按同一冻结特征流程重新计算，因评估分批/补齐方式不同，与历史日志可能存在约 0.02 个百分点以内差异。比较以本流程内参照为准。

## 全部逐类识别准确率和 F1

逐类“识别准确率”按 Recall=TP/该类真实样本数定义，避免一对多 Accuracy 被大量真负例抬高。下表比较诊断一最终调制结果；协议和所有分类头的逐类 Precision、Recall、F1、Support 均在 CSV 与各自 train.log 中。

| 调制类别 | 多任务 Recall | 多任务 F1 | 单任务 Recall | 单任务 F1 |
|---|---:|---:|---:|---:|
| OOK | 72.84% | 61.04% | 73.38% | 59.08% |
| BPSK | 51.62% | 53.41% | 50.58% | 50.11% |
| QPSK | 32.77% | 41.73% | 28.91% | 37.72% |
| 8PSK | 38.16% | 38.90% | 33.09% | 37.71% |
| 16QAM | 30.67% | 38.15% | 24.32% | 33.04% |
| 32QAM | 32.57% | 34.06% | 24.89% | 29.93% |
| 64QAM | 29.03% | 37.10% | 23.03% | 28.97% |
| 256QAM | 38.21% | 44.53% | 37.67% | 40.57% |
| OQPSK | 44.24% | 43.79% | 41.36% | 41.87% |
| 2FSK | 70.31% | 46.20% | 72.43% | 43.56% |
| 4FSK | 42.29% | 46.56% | 38.62% | 43.63% |
| MSK | 56.46% | 52.33% | 57.63% | 50.07% |
| 128QAM | 48.96% | 54.95% | 46.77% | 51.48% |
| AQPSK | 55.52% | 44.42% | 49.71% | 41.53% |
| CSS | 94.75% | 93.50% | 94.31% | 93.89% |
| GFSK | 87.51% | 89.72% | 86.64% | 87.74% |
| pi_4DQPSK | 92.58% | 90.72% | 90.98% | 88.95% |
| FM | 93.23% | 94.09% | 91.50% | 92.84% |
| Radar/Coherent Pulse Train | 97.15% | 95.30% | 96.52% | 94.82% |
| Radar/Barker Code | 88.34% | 89.02% | 86.49% | 86.97% |
| Radar/Polyphase Barker Code | 80.92% | 83.14% | 78.46% | 80.16% |
| Radar/Frank Code | 82.83% | 84.67% | 80.82% | 82.76% |
| Radar/LFM | 89.19% | 86.23% | 88.01% | 85.45% |

## 日志与文件

- [整体分类结果 CSV](classification_summary.csv)、[全部逐类指标 CSV](per_class_metrics.csv)、[完整 JSON](summary.json)、[对照图](diagnostic_comparison.png)。
- 可读日志：[多任务](joint/train.log)、[单任务](modulation_only/train.log)、[小模型冻结读出](frozen_small/train.log)、[大模型冻结读出](frozen_large/train.log)。
- train.log 保存总览、进度快照、逐类指标和收尾；逐 step/epoch 结构化事件单独保存在 events.jsonl。
- 正式训练入口、双进程训练及断点续训已做小规模执行检查，历史 JSON train.log 会保留为 train_legacy.jsonl。
- 用户在 main.json 中修改的模型参数和注释保持原样；配置读取增加 // 与 /* */ 注释支持。没有新增主配置文件，也未替换默认推理权重。

## 结果边界

- Task diagnostic uses one random initialization and a finite from-scratch 17M budget; it does not establish the absence of late-stage interference in 96M.
- Joint adds backbone AdamW updates; this is a net-effect test, not isolated proof of gradient conflict.
- Readouts use two seeds and one fixed optimizer recipe. Both fresh readouts use train-only standardization.
- Frozen reference heads are recomputed in the same feature pipeline; slight differences from older evaluation batching are possible.
- Validation was used to select original base checkpoints, so this is not an untouched hidden-test result.
