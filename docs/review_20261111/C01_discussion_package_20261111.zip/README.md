# C01 电磁感知模型：训练与推理代码

本项目实现一个共享时频双流基座，完成 23 类调制/波形识别、8 类体制识别和七项参数估计。包含分组数据划分、连续重建预训练、Atomic/Emergent 结构预训练、第二轮词表更新、多任务微调、评估、导出和统一推理。当前用于初步测试，未制作 Docker 镜像。

2026-11-11 诊断后优化已完成。全部 118,182 条本地验证记录上，调制 Accuracy **64.23% → 64.50%**，Macro-F1 **64.15% → 64.45%**；协议 Accuracy 保持 **94.42%**，七项参数误差完全一致。默认 `weights/` 已换为验证后的 96.32M 单模型，共享参数占 97.43%；原默认权重已备份。有效改动是冻结原 95M 共享基座，增加均值/标准差与 I/Q 统计读出并重训调制头。监督对比损失、局部残差前端未胜过控制组，默认关闭。提升有限，深层表征和扩参泛化瓶颈尚未解决，所有代理分均不代表官方成绩。完整实测及失败对照见 [本轮优化报告](artifacts/representation_optimization/20261111_122154_915261/report.md)。

原始基座来源为 `logs/supervised_main/20261110_233950_782228/best.pt`；优化后的完整权重为 `artifacts/representation_optimization/20261111_122154_915261/selected/model.pt`。前期诊断及六组增强对照见 [泛化报告](docs/generalization_20261111.md)，注意力/优化器修复见 [历史报告](docs/attention_repair_report.md)。

对外讨论可使用 [模型方案与验证总报告](docs/C01_model_and_validation_review_20261111.md)、[可编辑 Word](docs/C01_model_and_validation_review_20261111.docx) 或 [讨论资料包](docs/review_20261111/C01_discussion_package_20261111.zip)。总报告汇总截至 2026-11-11 的方案、历次验证、负结果、证据边界和下一步问题；资料包包含图表、指标 CSV 与原始证据，不包含原始波形或模型大权重。

训练配置已整理为模型、数据、训练预算、优化器、cosine 调度、损失、验证、检查点和运行设置。参数含义、影响与完整示例见 [配置说明](code/configs/README.md)。本轮配置及调度验证见 [配置更新测试报告](docs/config_v2_test_report.md)。

两项定位实验现已完成：[同调制曝光的单/多任务对照与冻结基座读出报告](artifacts/diagnostics/20261111_110649_079619/report.md)。复现入口为 `code/training/diagnose_tasks.py`、`diagnose_readout.py`，汇总入口为 `summarize_diagnostics.py`。所有验证均提供 Accuracy、Macro/Weighted-F1 和逐类指标；日志已拆分为可读的 `train.log` 与结构化的 `events.jsonl`。

## 环境与目录

当前可直接使用的解释器：

```bash
C01_PY=/home/yangqilin/anaconda3/envs/py313/bin/python
C01_DATA_ROOT=/mnt/disk1/wangxinbei_contest_dataset/C01
```

已使用 Python 3.13、PyTorch 2.13.0+cu130、NumPy 2.5.1、PyArrow 25.0.0 测试。原样例在 PyArrow 19.0.0 中存在读取问题，使用经验证的 25.0.0 环境。当前 CUDA 运行时是 13.0；赛题基线为 CUDA 12.x，正式提交前需在目标 CUDA/国产平台重新验证。项目没有改动任何现有环境或原始数据。

```text
code/
  infer.py                      # Parquet -> JSONL 统一入口；亦提供 Predictor API
  models/rf_model.py            # 时频对齐、动态门控、共享 Transformer、多任务头
  training/prepare_data.py      # 内容哈希分组、训练侧统计、mmap 缓存
  training/build_codebook.py    # Atomic 聚类、Emergent BPE、第二轮词表
  training/train.py             # 监督/自监督、混合精度、断点续训、DDP
  training/evaluate.py          # 两项分类、七项原单位误差
  training/export.py            # 单模型 safetensors 导出
  training/smoke_test.py        # 一键初步测试
  training/test_core.py         # 信息泄漏/有效位/BPE/数值/导出检查
  training/test_stability.py    # 注意力饱和、任务头动量保护与遮挡回归
  training/diagnose_gradients.py # 模块梯度、注意力尺度与熵定位
  training/repair_experiment.py # 固定批次和验证子集的真实数据修复对照
  training/diagnose_readout.py # 冻结编码器，比较均值/标准差/IQ统计读出
  training/promote_readout.py  # 将训练侧标准化与读出层合并为一个完整模型
  training/optimize_representation.py # 同初始化/采样流的 CE/SupCon 控制实验
  training/summarize_optimization.py # 汇总本轮实际优化与逐类指标
  configs/                     # 测试、小型、主模型和预训练配置
  utils/                       # 数据、损失、结构词表、接口校验与运行环境
weights/                       # 正式训练后导出的 config.json/model.safetensors
artifacts/                     # 数据审计、缓存、实验检查点及测试产物
environment/                   # 当前环境记录与依赖声明
docs/                          # 实现说明和初测报告
logs/                          # 推理日志；各实验另有自己的 train.log
```

本机双卡只允许 `0,1`、`2,3`、`4,5`。启动脚本和训练运行时均检查这一限制。以下双卡例子使用 `0,1`，请只选择已分配给你的同组设备。

本地双卡测试发现当前环境的 NCCL 主机 cuMem 分配路径会导致崩溃；关闭该路径后最小通信和完整 DDP 训练均通过。训练进程在双卡时默认设置 `NCCL_CUMEM_HOST_ENABLE=0`，不禁用 GPU P2P，不修改系统配置；显式环境值可覆盖。该回退方式也见 [NVIDIA NCCL 运行时说明](https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/troubleshooting/runtime_and_mpi_issues.html)。

## 一键初步测试

在项目根目录执行：

```bash
"$C01_PY" code/training/smoke_test.py \
  --data-root "$C01_DATA_ROOT" \
  --output artifacts/my_first_smoke \
  --gpu 0
```

需要额外检查双卡时，增加 `--ddp-gpus 0,1`。每次选择新的输出目录，避免覆盖实验结果。默认构建每个任务、每个 split 约 96 条记录的测试缓存，并保持重复组完整，因此实际数量略大。底层分组依据 90/10 哈希划分；小测试集对两侧分别限额，所以选出后的样本数比例可以接近 1:1。

脚本依次测试：关键回归检查、数据缓存、监督训练与续训、波形重建、首轮词表、纯结构预训练、教师特征重建词表、第二轮混合目标预训练、联合微调、评估、导出、GPU/CPU 推理及 JSONL 校验。测试模型为 64 宽、2 层、32/64 结构词表，只用于检验代码路径，不代表比赛模型精度。

结果在输出目录的 `smoke_status.json`，每一步的完整日志在 `logs/`。通过后的权重在 `weights/`，官方样例预测在 `prediction_device.jsonl` 与 `prediction_cpu.jsonl`。GPU 与 CPU 的浮点数不要求逐位一致，分类/参数分别按同一模型计算。

中断后可对同一输出目录增加 `--resume`，保留已经通过的阶段，继续失败或未执行的阶段；关键回归检查会重新运行。

## 准备全量训练数据

已有全量审计索引时：

```bash
"$C01_PY" code/training/prepare_data.py \
  --data-root "$C01_DATA_ROOT" \
  --manifest artifacts/c01_data_audit/sample_manifest.parquet \
  --output artifacts/data_full
```

如需重新审计数据版本：

```bash
"$C01_PY" code/utils/audit_c01_dataset.py \
  --data-root "$C01_DATA_ROOT" \
  --output-dir artifacts/c01_data_audit
```

缓存输出 `iq.npy`、`metadata.npz`、`dataset.json` 和 `split_manifest.parquet`。原始 I/Q 保留 Float32，按最长 1024 点缓存；全量约需 10 GB 级别空间。读取时按长度裁切，并由训练采样器按长度组批。源码中的每条波形会再次核对与审计哈希一致。

数据处理保证：同内容哈希不跨 split、六个接口样例及其重复组隔离、目标中心/尺度和参数码表只由训练侧计算。元数据不含可用于推理的答案捷径；ID 仅负责记录与回填。

## 建立联合监督基线

先单卡启动小型模型：

```bash
CUDA_VISIBLE_DEVICES=0 "$C01_PY" code/training/train.py \
  --data artifacts/data_full --config code/configs/small.json \
  --output artifacts/supervised_small
```

主模型双卡训练：

```bash
CUDA_VISIBLE_DEVICES=0,1 "$C01_PY" -m torch.distributed.run \
  --standalone --nproc_per_node=2 code/training/train.py \
  --data artifacts/data_full --config code/configs/main.json \
  --output artifacts/supervised_main

C01_MAIN_RUN=$("$C01_PY" code/utils/run_directory.py --latest artifacts/supervised_main)
```

主监督训练统一使用 `main.json`；模型规模、前端、任务头及优化配方均在其中调整，运行时以保存的 `resolved_config.json` 为准。配置文件支持 `//`、`/* */` 注释，便于在一个文件中保留参数说明。`data.batch_size` 是每卡微批次；每卡 256、累积 1 次时，双卡有效全局 batch 为 512。可使用 `--batch-size`、`--epochs` 覆盖。cosine、预热和最低学习率比例位于 `scheduler`，步数按优化器更新计算。

`--max-steps 30` 可做短跑；`--merge-paired` 只在训练侧合并同波形的已知跨任务标签，与不合并分别比较。训练按三个任务等配额轮转，任务内按真实长度比例抽样；这是有放回的均衡更新预算，不等同于每轮恰好遍历每条记录一次。

主配置已启用 `model.encoder.qk_normalization` 和 `optimizer.skip_inactive_heads`，峰值学习率为 1e-4。继续相同配方使用 `--resume`；更换优化配方并保留全部任务头时使用 `--warmstart-checkpoint`，它会重置优化器；`--init-checkpoint` 只载入基座。已启动的进程不会自动加载源文件改动。

`main.json` 现已对齐优化模型结构：768 宽、12 层、8 heads，`classification_pooling="mean_std"`、`physical_statistics=true`、`classification_fp32=true`。统计量只由有效 I/Q 计算；训练侧标准化已经折入导出模型，无需加载离线特征。该配置用于后续联合训练，不等同于本轮已完成的“原基座 + 冻结读出”两阶段训练，也不保证从头训练收益。直接测试当前精度使用已有 `weights/`，无需重训。

如需在当前模型上继续联合微调，将 `--warmstart-checkpoint artifacts/representation_optimization/20261111_122154_915261/selected/model.pt` 加到主训练命令中。合并权重没有原读出训练的优化器状态，不能用 `--resume`；`--init-checkpoint` 会重新初始化任务头，不适用于保留本轮优化。修改模型宽度/深度会使这份权重不兼容，需另行训练。

`--output` 指定实验父目录，新训练自动创建上海时区的时间戳子目录，例如 `artifacts/supervised_main/20261110_153000_123456/`。同一命令重复启动会生成不同目录，双卡共享一个目录。终端总览会显示实际路径；父目录的 `latest_run.json` 记录最近创建的运行，上述辅助命令读取该路径。续训应选择确定的检查点，最新目录不等同于最佳模型。

每次运行目录包含 `best.pt`、`last.pt`、`metrics.json`、`parameter_report.json`、`resolved_config.json`、`train.log`、`events.jsonl` 和 `run_info.json`。`best.pt` 按 `evaluation.selection_metric` 选择，当前主配置为调制准确率，同时始终报告协议与参数误差；`auto` 在监督阶段按本地代理分选择，代理分不是官方成绩。断点续训要求保持配置、数据划分、世界大小、词表及配对合并方式一致，并继续写入检查点所在的原目录：

终端先输出训练总览，再逐 epoch 显示 step 进度、平均损失、主要分项和学习率；验证输出调制/协议的 Accuracy、Macro-F1、Weighted-F1，以及逐类 Recall（该类识别准确率）、Precision、F1、Support 和七项参数 RMSE。双卡仅主进程显示。

`train.log` 保存同样的可读总览、定期进度快照、完整验证表及收尾信息，不再混入 JSON 或终端重绘控制符。机器可读的逐 step/epoch 记录单独写入 `events.jsonl`，完整指标保存在 `metrics.json`。恢复历史 JSON 版日志的运行时，原 `train.log` 会先保留为 `train_legacy.jsonl`（重名时递增后缀），再开始可读日志；旧记录不会丢失。`runtime.progress_bar`、`progress_min_interval` 控制终端进度条，`runtime.log_every` 控制事件及文件内进度快照的步数间隔。

```bash
CUDA_VISIBLE_DEVICES=0,1 "$C01_PY" -m torch.distributed.run \
  --standalone --nproc_per_node=2 code/training/train.py \
  --data artifacts/data_full --config code/configs/main.json \
  --resume "$C01_MAIN_RUN/last.pt"
```

## 预训练候选一：I/Q 掩码重建

```bash
CUDA_VISIBLE_DEVICES=0,1 "$C01_PY" -m torch.distributed.run \
  --standalone --nproc_per_node=2 code/training/train.py \
  --data artifacts/data_full --config code/configs/pretrain_reconstruction.json \
  --stage pretrain --output artifacts/pretrain_reconstruction
```

时域、局部时频谱、全窗频谱和相位特征均从同一受遮挡输入生成。RMS 只由可见点计算，完整 I/Q 仅进入目标分支。配置 `loss.pretraining.mask.ratio`、`span` 控制遮挡量与连续跨度。

可设置 `loss.pretraining.mask.strategy: "energy_mixed"`，使一部分遮挡位置依能量加权选择、其余随机选取，总遮挡数量保持相同。这是关键区域掩码的项目实现候选，不是对讲座未披露阈值算法的复现。`loss.pretraining.weights.spectrum` 可增加局部 Patch 功率谱辅助目标，先保持为 0 做独立对照。

## 预训练候选二：Atomic/Emergent 结构学习

第一轮词表默认 512 个原子单元、最多 512 次合并、组合最长 5 个原子位置：

```bash
CUDA_VISIBLE_DEVICES=0 "$C01_PY" code/training/build_codebook.py \
  --data artifacts/data_full --output artifacts/codebook_v1
```

构建时按任务/长度平衡抽样局部特征，使用归一化聚类。BPE 仅由训练侧记录学习，按记录边界合并，然后流式给训练与验证赋固定词表标签。词表拟合上限由 `--max-patches`、`--bpe-samples` 控制，实际合并次数和容量写入 `codebook.json`；数据不足时不会虚构不存在的组合。这个实现是根据成果介绍设计的参赛适配。

第一轮结构训练：

```bash
CUDA_VISIBLE_DEVICES=0,1 "$C01_PY" -m torch.distributed.run \
  --standalone --nproc_per_node=2 code/training/train.py \
  --data artifacts/data_full --config code/configs/pretrain_structure.json \
  --stage pretrain --codebook artifacts/codebook_v1 \
  --output artifacts/structure_v1

C01_STRUCTURE_V1_RUN=$("$C01_PY" code/utils/run_directory.py --latest artifacts/structure_v1)
```

第二轮用冻结编码器特征重建词表，再从第一轮共同基座继续训练，结构预测头重新初始化：

```bash
CUDA_VISIBLE_DEVICES=0 "$C01_PY" code/training/build_codebook.py \
  --data artifacts/data_full --output artifacts/codebook_v2 \
  --teacher-checkpoint "$C01_STRUCTURE_V1_RUN/best.pt"

CUDA_VISIBLE_DEVICES=0,1 "$C01_PY" -m torch.distributed.run \
  --standalone --nproc_per_node=2 code/training/train.py \
  --data artifacts/data_full --config code/configs/pretrain_structure.json \
  --stage pretrain --codebook artifacts/codebook_v2 \
  --init-checkpoint "$C01_STRUCTURE_V1_RUN/best.pt" \
  --output artifacts/structure_v2

C01_STRUCTURE_V2_RUN=$("$C01_PY" code/utils/run_directory.py --latest artifacts/structure_v2)
```

`loss.pretraining.weights` 中的 `atomic`、`emergent`、`reconstruction` 控制目标组合。Atomic-only 对照设 `emergent=0`；混合目标可把 `reconstruction` 设为 0.1。所有实验使用新配置文件和新输出目录。`loss.pretraining.equalize_emergent_spans=true` 可按组合长度调整回填损失权重，默认关闭。

## 共同微调、评估、导出

```bash
CUDA_VISIBLE_DEVICES=0,1 "$C01_PY" -m torch.distributed.run \
  --standalone --nproc_per_node=2 code/training/train.py \
  --data artifacts/data_full --config code/configs/finetune.json \
  --init-checkpoint "$C01_STRUCTURE_V2_RUN/best.pt" \
  --output artifacts/finetuned_main

C01_FINETUNE_RUN=$("$C01_PY" code/utils/run_directory.py --latest artifacts/finetuned_main)

CUDA_VISIBLE_DEVICES=0 "$C01_PY" code/training/evaluate.py \
  --data artifacts/data_full --checkpoint "$C01_FINETUNE_RUN/best.pt" \
  --output "$C01_FINETUNE_RUN/evaluation_fp32.json"

"$C01_PY" code/training/export.py \
  --checkpoint "$C01_FINETUNE_RUN/best.pt" --output weights
```

评估输出两个混淆矩阵、准确率和宏平均召回、七项有效样本数/原单位 RMSE/MAE/P95。训练损失使用训练侧标准化量，评估和导出预测恢复原始数值尺度。频移有效真零参与损失，无效 NaN/零不参与。

导出移除全部训练辅助头，保存 `weights/config.json` 与 `weights/model.safetensors`，逐张量校验读写一致，再检查参数量和共享比例。自带标准 safetensors 读写器，无需额外下载依赖。最终推理不加载词表或教师，也不加载多个任务专属基座。

## 统一推理与结果校验

```bash
CUDA_VISIBLE_DEVICES=0 "$C01_PY" code/infer.py \
  --input "$C01_DATA_ROOT/rf_signal_sample_io_v1.0/rf_signal_sample_io_input_v1.0.parquet" \
  --output artifacts/predictions.jsonl --weights weights \
  --log logs/inference.json

"$C01_PY" code/utils/validate_output.py \
  --input "$C01_DATA_ROOT/rf_signal_sample_io_v1.0/rf_signal_sample_io_input_v1.0.parquet" \
  --output artifacts/predictions.jsonl \
  --schema "$C01_DATA_ROOT/rf_signal_benchmark_train_v1.0/task_schema.json"
```

输入仅需 `task/sample_id/iq`，输出保持原顺序。两种分类返回 Schema 原字符串；参数返回全部七项有限数字，不输出有效位。`--device cpu` 支持 CPU；`--spectral-backend matmul` 用实数矩阵乘替代全窗 FFT，局部 STFT 本来就使用实数固定卷积，便于后续平台适配。实际国产平台尚未验证。

当前官方接口只明确文件格式，未披露最终命令签名；本项目提供上述 CLI 和 `Predictor.predict(records)` Python API，收到正式调用约定后可做轻量适配。当前没有采样率字段，使用样点坐标；模型 API 支持已知采样率时的物理 RoPE，但现有数据 CLI 不推测采样率。

模型和输入无关的关键检查可独立运行：

```bash
"$C01_PY" code/training/test_core.py
```

更多说明见 [实现说明](docs/implementation.md) 和 [初步测试报告](docs/self_test_report.md)。全量长期训练、比赛精度和目标平台迁移仍需后续实验确认。
